#ifdef JEMALLOC_INTERNAL_TSD_MALLOC_THREAD_CLEANUP_H
#	error This file should be included only once, by tsd.h.
#endif
#define JEMALLOC_INTERNAL_TSD_MALLOC_THREAD_CLEANUP_H

#include "jemalloc/internal/jemalloc_preamble.h"
#include "jemalloc/internal/tsd_internals.h"
#include "jemalloc/internal/tsd_tls_addr.h"
#include "jemalloc/internal/tsd_types.h"

#define JEMALLOC_TSD_TYPE_ATTR(type) __thread type JEMALLOC_TLS_MODEL

extern JEMALLOC_TSD_TYPE_ATTR(tsd_t) tsd_tls;
extern JEMALLOC_TSD_TYPE_ATTR(bool) tsd_initialized;
extern bool tsd_booted;

JEMALLOC_TLS_ADDR_DECLARE(tsd_tls)
JEMALLOC_TLS_ADDR_DECLARE(tsd_initialized)

/* Initialization/cleanup. */
JEMALLOC_ALWAYS_INLINE bool
tsd_cleanup_wrapper(void) {
	if (tsd_initialized) {
		tsd_initialized = false;
		tsd_cleanup(&tsd_tls);
	}
	return tsd_initialized;
}

JEMALLOC_ALWAYS_INLINE bool
tsd_boot0(void) {
	_malloc_tsd_cleanup_register(&tsd_cleanup_wrapper);
	tsd_booted = true;
	return false;
}

JEMALLOC_ALWAYS_INLINE void
tsd_boot1(void) {
	/* Do nothing. */
}

JEMALLOC_ALWAYS_INLINE bool
tsd_boot(void) {
	return tsd_boot0();
}

JEMALLOC_ALWAYS_INLINE bool
tsd_booted_get(void) {
	return tsd_booted;
}

JEMALLOC_ALWAYS_INLINE bool
tsd_get_allocates(void) {
	return false;
}

JEMALLOC_ALWAYS_INLINE bool
tsd_teardown_done(void) {
	return false;
}

/* Get/set. */
JEMALLOC_ALWAYS_INLINE tsd_t *
tsd_get(bool init) {
	return JEMALLOC_TLS_ADDR(tsd_tls);
}
JEMALLOC_ALWAYS_INLINE void
tsd_set(tsd_t *val) {
	tsd_t *tsd = JEMALLOC_TLS_ADDR(tsd_tls);

	assert(tsd_booted);
	if (likely(tsd != val)) {
		*tsd = (*val);
	}
	*JEMALLOC_TLS_ADDR(tsd_initialized) = true;
}
