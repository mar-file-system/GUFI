#include "test/jemalloc_test.h"

extern uint64_t prof_sample_weighted_size(
    size_t size, size_t usize, size_t unbiased_size);

/*
 * The MALLOC_CONF of this test has lg_prof_sample:0, meaning that every single
 * allocation will be sampled (and trigger relevant hooks).
 */

const char *dump_filename = "/dev/null";

prof_backtrace_hook_t default_bt_hook;

bool mock_bt_hook_called = false;
bool mock_dump_hook_called = false;
bool mock_prof_sample_hook_called = false;
bool mock_prof_sample_free_hook_called = false;

void  *sampled_ptr = NULL;
size_t sampled_ptr_sz = 0;
size_t sampled_ptr_usz = 0;
void  *free_sampled_ptr = NULL;
size_t free_sampled_ptr_sz = 0;

void
mock_bt_hook(void **vec, unsigned *len, unsigned max_len) {
	*len = max_len;
	for (unsigned i = 0; i < max_len; ++i) {
		vec[i] = (void *)((uintptr_t)i);
	}
	mock_bt_hook_called = true;
}

void
mock_bt_augmenting_hook(void **vec, unsigned *len, unsigned max_len) {
	default_bt_hook(vec, len, max_len);
	expect_u_gt(*len, 0, "Default backtrace hook returned empty backtrace");
	expect_u_lt(*len, max_len,
	    "Default backtrace hook returned too large backtrace");

	/* Add a separator between default frames and augmented */
	vec[*len] = (void *)0x030303030;
	(*len)++;

	/* Add more stack frames */
	for (unsigned i = 0; i < 3; ++i) {
		if (*len == max_len) {
			break;
		}
		vec[*len] = (void *)((uintptr_t)i);
		(*len)++;
	}

	mock_bt_hook_called = true;
}

void
mock_dump_hook(const char *filename) {
	mock_dump_hook_called = true;
	expect_str_eq(filename, dump_filename,
	    "Incorrect file name passed to the dump hook");
}

void
mock_prof_sample_hook(
    const void *ptr, size_t sz, void **vec, unsigned len, size_t usz) {
	mock_prof_sample_hook_called = true;
	sampled_ptr = (void *)ptr;
	sampled_ptr_sz = sz;
	sampled_ptr_usz = usz;
	for (unsigned i = 0; i < len; i++) {
		expect_ptr_not_null(
		    (void **)vec[i], "Backtrace should not contain NULL");
	}
}

void
mock_prof_sample_free_hook(const void *ptr, size_t sz) {
	mock_prof_sample_free_hook_called = true;
	free_sampled_ptr = (void *)ptr;
	free_sampled_ptr_sz = sz;
}

TEST_BEGIN(test_prof_backtrace_hook_replace) {
	test_skip_if(!config_prof);

	mock_bt_hook_called = false;

	void *p0 = mallocx(1, 0);
	assert_ptr_not_null(p0, "Failed to allocate");

	expect_false(mock_bt_hook_called, "Called mock hook before it's set");

	prof_backtrace_hook_t null_hook = NULL;
	expect_d_eq(mallctl("experimental.hooks.prof_backtrace", NULL, 0,
	                (void *)&null_hook, sizeof(null_hook)),
	    EINVAL, "Incorrectly allowed NULL backtrace hook");

	size_t default_bt_hook_sz = sizeof(prof_backtrace_hook_t);
	prof_backtrace_hook_t hook = &mock_bt_hook;
	expect_d_eq(mallctl("experimental.hooks.prof_backtrace",
	                (void *)&default_bt_hook, &default_bt_hook_sz,
	                (void *)&hook, sizeof(hook)),
	    0, "Unexpected mallctl failure setting hook");

	void *p1 = mallocx(1, 0);
	assert_ptr_not_null(p1, "Failed to allocate");

	expect_true(mock_bt_hook_called, "Didn't call mock hook");

	prof_backtrace_hook_t current_hook;
	size_t                current_hook_sz = sizeof(prof_backtrace_hook_t);
	prof_backtrace_hook_t attempted_hook = &mock_bt_augmenting_hook;

	current_hook_sz = sizeof(prof_backtrace_hook_t) - 1;
	expect_d_eq(mallctl("experimental.hooks.prof_backtrace",
	                (void *)&current_hook, &current_hook_sz,
	                (void *)&attempted_hook, sizeof(attempted_hook)),
	    EINVAL, "Unexpected mallctl success with malformed oldlen");

	current_hook_sz = sizeof(prof_backtrace_hook_t);
	expect_d_eq(mallctl("experimental.hooks.prof_backtrace",
	                (void *)&current_hook, &current_hook_sz, NULL, 0),
	    0, "Unexpected mallctl failure reading hook");
	expect_ptr_eq(current_hook, hook,
	    "Malformed oldlen should not update hook");

	expect_d_eq(mallctl("experimental.hooks.prof_backtrace", NULL, NULL,
	                (void *)&attempted_hook, sizeof(attempted_hook) - 1),
	    EINVAL, "Unexpected mallctl success with malformed newlen");

	current_hook_sz = sizeof(prof_backtrace_hook_t);
	expect_d_eq(mallctl("experimental.hooks.prof_backtrace",
	                (void *)&current_hook, &current_hook_sz, NULL, 0),
	    0, "Unexpected mallctl failure reading hook");
	expect_ptr_eq(current_hook, hook,
	    "Malformed newlen should not update hook");

	expect_d_eq(mallctl("experimental.hooks.prof_backtrace",
	                (void *)&current_hook, &current_hook_sz,
	                (void *)&default_bt_hook, sizeof(default_bt_hook)),
	    0, "Unexpected mallctl failure resetting hook to default");

	expect_ptr_eq(current_hook, hook,
	    "Hook returned by mallctl is not equal to mock hook");

	dallocx(p1, 0);
	dallocx(p0, 0);
}
TEST_END

TEST_BEGIN(test_prof_backtrace_hook_augment) {
	test_skip_if(!config_prof);

	mock_bt_hook_called = false;

	void *p0 = mallocx(1, 0);
	assert_ptr_not_null(p0, "Failed to allocate");

	expect_false(mock_bt_hook_called, "Called mock hook before it's set");

	size_t default_bt_hook_sz = sizeof(prof_backtrace_hook_t);
	prof_backtrace_hook_t hook = &mock_bt_augmenting_hook;
	expect_d_eq(mallctl("experimental.hooks.prof_backtrace",
	                (void *)&default_bt_hook, &default_bt_hook_sz,
	                (void *)&hook, sizeof(hook)),
	    0, "Unexpected mallctl failure setting hook");

	void *p1 = mallocx(1, 0);
	assert_ptr_not_null(p1, "Failed to allocate");

	expect_true(mock_bt_hook_called, "Didn't call mock hook");

	prof_backtrace_hook_t current_hook;
	size_t                current_hook_sz = sizeof(prof_backtrace_hook_t);
	expect_d_eq(mallctl("experimental.hooks.prof_backtrace",
	                (void *)&current_hook, &current_hook_sz,
	                (void *)&default_bt_hook, sizeof(default_bt_hook)),
	    0, "Unexpected mallctl failure resetting hook to default");

	expect_ptr_eq(current_hook, hook,
	    "Hook returned by mallctl is not equal to mock hook");

	dallocx(p1, 0);
	dallocx(p0, 0);
}
TEST_END

TEST_BEGIN(test_prof_dump_hook) {
	test_skip_if(!config_prof);
	expect_u_eq(opt_prof_bt_max, 200, "Unexpected backtrace stack depth");

	mock_dump_hook_called = false;

	expect_d_eq(mallctl("prof.dump", NULL, NULL, (void *)&dump_filename,
	                sizeof(dump_filename)),
	    0, "Failed to dump heap profile");

	expect_false(mock_dump_hook_called, "Called dump hook before it's set");

	size_t           default_bt_hook_sz = sizeof(prof_dump_hook_t);
	prof_dump_hook_t hook = &mock_dump_hook;
	expect_d_eq(
	    mallctl("experimental.hooks.prof_dump", (void *)&default_bt_hook,
	        &default_bt_hook_sz, (void *)&hook, sizeof(hook)),
	    0, "Unexpected mallctl failure setting hook");

	expect_d_eq(mallctl("prof.dump", NULL, NULL, (void *)&dump_filename,
	                sizeof(dump_filename)),
	    0, "Failed to dump heap profile");

	expect_true(mock_dump_hook_called, "Didn't call mock hook");

	prof_dump_hook_t current_hook;
	size_t           current_hook_sz = sizeof(prof_dump_hook_t);
	prof_dump_hook_t attempted_hook = NULL;

	current_hook_sz = sizeof(prof_dump_hook_t) - 1;
	expect_d_eq(mallctl("experimental.hooks.prof_dump",
	                (void *)&current_hook, &current_hook_sz,
	                (void *)&attempted_hook, sizeof(attempted_hook)),
	    EINVAL, "Unexpected mallctl success with malformed oldlen");

	current_hook_sz = sizeof(prof_dump_hook_t);
	expect_d_eq(mallctl("experimental.hooks.prof_dump",
	                (void *)&current_hook, &current_hook_sz, NULL, 0),
	    0, "Unexpected mallctl failure reading hook");
	expect_ptr_eq(current_hook, hook,
	    "Malformed oldlen should not update hook");

	expect_d_eq(mallctl("experimental.hooks.prof_dump", NULL, NULL,
	                (void *)&attempted_hook, sizeof(attempted_hook) - 1),
	    EINVAL, "Unexpected mallctl success with malformed newlen");

	current_hook_sz = sizeof(prof_dump_hook_t);
	expect_d_eq(mallctl("experimental.hooks.prof_dump",
	                (void *)&current_hook, &current_hook_sz, NULL, 0),
	    0, "Unexpected mallctl failure reading hook");
	expect_ptr_eq(current_hook, hook,
	    "Malformed newlen should not update hook");

	expect_d_eq(mallctl("experimental.hooks.prof_dump",
	                (void *)&current_hook, &current_hook_sz,
	                (void *)&default_bt_hook, sizeof(default_bt_hook)),
	    0, "Unexpected mallctl failure resetting hook to default");

	expect_ptr_eq(current_hook, hook,
	    "Hook returned by mallctl is not equal to mock hook");
}
TEST_END

/* Need the do_write flag because NULL is a valid to_write value. */
static void
read_write_prof_sample_hook(
    prof_sample_hook_t *to_read, bool do_write, prof_sample_hook_t to_write) {
	size_t hook_sz = sizeof(prof_sample_hook_t);
	expect_d_eq(mallctl("experimental.hooks.prof_sample", (void *)to_read,
	                &hook_sz, do_write ? &to_write : NULL, hook_sz),
	    0, "Unexpected prof_sample_hook mallctl failure");
}

static void
write_prof_sample_hook(prof_sample_hook_t new_hook) {
	read_write_prof_sample_hook(NULL, true, new_hook);
}

static prof_sample_hook_t
read_prof_sample_hook(void) {
	prof_sample_hook_t curr_hook;
	read_write_prof_sample_hook(&curr_hook, false, NULL);

	return curr_hook;
}

static void
read_write_prof_sample_free_hook(prof_sample_free_hook_t *to_read,
    bool do_write, prof_sample_free_hook_t to_write) {
	size_t hook_sz = sizeof(prof_sample_free_hook_t);
	expect_d_eq(
	    mallctl("experimental.hooks.prof_sample_free", (void *)to_read,
	        &hook_sz, do_write ? &to_write : NULL, hook_sz),
	    0, "Unexpected prof_sample_free_hook mallctl failure");
}

static void
write_prof_sample_free_hook(prof_sample_free_hook_t new_hook) {
	read_write_prof_sample_free_hook(NULL, true, new_hook);
}

static prof_sample_free_hook_t
read_prof_sample_free_hook(void) {
	prof_sample_free_hook_t curr_hook;
	read_write_prof_sample_free_hook(&curr_hook, false, NULL);

	return curr_hook;
}

static void
check_prof_sample_hooks(bool sample_hook_set, bool sample_free_hook_set) {
	expect_false(mock_prof_sample_hook_called,
	    "Should not have called prof_sample hook");
	expect_false(mock_prof_sample_free_hook_called,
	    "Should not have called prof_sample_free hook");
	expect_ptr_null(sampled_ptr, "Unexpected sampled ptr");
	expect_zu_eq(sampled_ptr_sz, 0, "Unexpected sampled ptr size");
	expect_zu_eq(sampled_ptr_usz, 0, "Unexpected sampled ptr usize");
	expect_ptr_null(free_sampled_ptr, "Unexpected free sampled ptr");
	expect_zu_eq(
	    free_sampled_ptr_sz, 0, "Unexpected free sampled ptr size");

	prof_sample_hook_t curr_hook = read_prof_sample_hook();
	expect_ptr_eq(curr_hook, sample_hook_set ? mock_prof_sample_hook : NULL,
	    "Unexpected non NULL default hook");

	prof_sample_free_hook_t curr_free_hook = read_prof_sample_free_hook();
	expect_ptr_eq(curr_free_hook,
	    sample_free_hook_set ? mock_prof_sample_free_hook : NULL,
	    "Unexpected non NULL default hook");

	size_t alloc_sz = 10;
	size_t alloc_usz = 16;
	void  *p = mallocx(alloc_sz, 0);
	expect_ptr_not_null(p, "Failed to allocate");
	expect_true(mock_prof_sample_hook_called == sample_hook_set,
	    "Incorrect prof_sample hook usage");
	if (sample_hook_set) {
		expect_ptr_eq(p, sampled_ptr, "Unexpected sampled ptr");
		expect_zu_eq(
		    alloc_sz, sampled_ptr_sz, "Unexpected sampled usize");
		expect_zu_eq(
		    alloc_usz, sampled_ptr_usz, "Unexpected sampled usize");
	}

	dallocx(p, 0);
	expect_true(mock_prof_sample_free_hook_called == sample_free_hook_set,
	    "Incorrect prof_sample_free hook usage");
	if (sample_free_hook_set) {
		size_t usz = sz_s2u(alloc_sz);
		expect_ptr_eq(p, free_sampled_ptr, "Unexpected sampled ptr");
		expect_zu_eq(
		    usz, free_sampled_ptr_sz, "Unexpected sampled usize");
	}

	sampled_ptr = free_sampled_ptr = NULL;
	sampled_ptr_sz = sampled_ptr_usz = free_sampled_ptr_sz = 0;
	mock_prof_sample_hook_called = false;
	mock_prof_sample_free_hook_called = false;
}

TEST_BEGIN(test_prof_sample_hooks) {
	test_skip_if(!config_prof);

	check_prof_sample_hooks(false, false);

	write_prof_sample_hook(mock_prof_sample_hook);
	check_prof_sample_hooks(true, false);

	write_prof_sample_free_hook(mock_prof_sample_free_hook);
	check_prof_sample_hooks(true, true);

	prof_sample_hook_t attempted_sample_hook = NULL;
	prof_sample_hook_t sample_hook;
	size_t             sample_hook_sz = sizeof(prof_sample_hook_t) - 1;
	expect_d_eq(mallctl("experimental.hooks.prof_sample",
	                (void *)&sample_hook, &sample_hook_sz,
	                (void *)&attempted_sample_hook,
	                sizeof(attempted_sample_hook)),
	    EINVAL, "Unexpected mallctl success with malformed oldlen");
	expect_ptr_eq(read_prof_sample_hook(), mock_prof_sample_hook,
	    "Malformed oldlen should not update prof_sample hook");

	expect_d_eq(mallctl("experimental.hooks.prof_sample", NULL, NULL,
	                (void *)&attempted_sample_hook,
	                sizeof(attempted_sample_hook) - 1),
	    EINVAL, "Unexpected mallctl success with malformed newlen");
	expect_ptr_eq(read_prof_sample_hook(), mock_prof_sample_hook,
	    "Malformed newlen should not update prof_sample hook");

	prof_sample_free_hook_t attempted_sample_free_hook = NULL;
	prof_sample_free_hook_t sample_free_hook;
	size_t sample_free_hook_sz = sizeof(prof_sample_free_hook_t) - 1;
	expect_d_eq(mallctl("experimental.hooks.prof_sample_free",
	                (void *)&sample_free_hook, &sample_free_hook_sz,
	                (void *)&attempted_sample_free_hook,
	                sizeof(attempted_sample_free_hook)),
	    EINVAL, "Unexpected mallctl success with malformed oldlen");
	expect_ptr_eq(read_prof_sample_free_hook(), mock_prof_sample_free_hook,
	    "Malformed oldlen should not update prof_sample_free hook");

	expect_d_eq(mallctl("experimental.hooks.prof_sample_free", NULL, NULL,
	                (void *)&attempted_sample_free_hook,
	                sizeof(attempted_sample_free_hook) - 1),
	    EINVAL, "Unexpected mallctl success with malformed newlen");
	expect_ptr_eq(read_prof_sample_free_hook(), mock_prof_sample_free_hook,
	    "Malformed newlen should not update prof_sample_free hook");

	write_prof_sample_hook(NULL);
	check_prof_sample_hooks(false, true);

	write_prof_sample_free_hook(NULL);
	check_prof_sample_hooks(false, false);

	/* Test read+write together. */
	read_write_prof_sample_hook(&sample_hook, true, mock_prof_sample_hook);
	expect_ptr_null(sample_hook, "Unexpected non NULL default hook");
	check_prof_sample_hooks(true, false);

	read_write_prof_sample_free_hook(
	    &sample_free_hook, true, mock_prof_sample_free_hook);
	expect_ptr_null(sample_free_hook, "Unexpected non NULL default hook");
	check_prof_sample_hooks(true, true);

	read_write_prof_sample_hook(&sample_hook, true, NULL);
	expect_ptr_eq(
	    sample_hook, mock_prof_sample_hook, "Unexpected prof_sample hook");
	check_prof_sample_hooks(false, true);

	read_write_prof_sample_free_hook(&sample_free_hook, true, NULL);
	expect_ptr_eq(sample_free_hook, mock_prof_sample_free_hook,
	    "Unexpected prof_sample_free hook");
	check_prof_sample_hooks(false, false);
}
TEST_END

TEST_BEGIN(test_prof_hook_noop) {
	test_skip_if(!config_prof);

	const char *hooks[] = {"experimental.hooks.prof_backtrace",
	    "experimental.hooks.prof_dump", "experimental.hooks.prof_sample",
	    "experimental.hooks.prof_sample_free"};

	/* Passing NULL for both oldp and newp must always return EINVAL. */
	for (unsigned i = 0; i < sizeof(hooks) / sizeof(hooks[0]); i++) {
		expect_d_eq(mallctl(hooks[i], NULL, NULL, NULL, 0), EINVAL,
		    "Unexpected noop hook mallctl result");
	}

	/*
	 * Passing a pointer to a NULL function pointer:
	 *   prof_backtrace requires a non-NULL hook  -> EINVAL (unchanged)
	 *   prof_dump / prof_sample / prof_sample_free allow unsetting -> 0
	 *
	 * For the latter, save and restore the prior value so this test
	 * doesn't leak NULL hook state to any future test.
	 */
	prof_backtrace_hook_t bt_null = NULL;
	expect_d_eq(mallctl(hooks[0], NULL, NULL, &bt_null, sizeof(bt_null)),
	    EINVAL, "Incorrectly allowed NULL backtrace hook");

	for (unsigned i = 1; i < sizeof(hooks) / sizeof(hooks[0]); i++) {
		void  *saved    = NULL;
		size_t saved_sz = sizeof(saved);
		void  *new_hook = NULL;
		/* Read current value into `saved`, write NULL in same call. */
		expect_d_eq(mallctl(hooks[i], &saved, &saved_sz,
		                &new_hook, sizeof(new_hook)),
		    0, "Unexpected null-hook mallctl result");
		/* Restore. */
		expect_d_eq(mallctl(hooks[i], NULL, NULL,
		                &saved, sizeof(saved)),
		    0, "Failed to restore hook");
	}
}
TEST_END

TEST_BEGIN(test_prof_sample_weighted_size) {
	test_skip_if(!config_prof);

	expect_u64_eq(prof_sample_weighted_size(17, 32, 32), 17,
	    "A probability of one should preserve requested size");
	expect_u64_eq(prof_sample_weighted_size(17, 32, 48), 26,
	    "Weighted requested size should round to the nearest byte");
	expect_u64_eq(prof_sample_weighted_size(0, 8, SIZE_T_MAX), 0,
	    "A zero-byte request should have zero weight");
	/*
	 * Realistic sampling point: R = 512 KiB, usize = 128,
	 * unbiased = round(128 / (1 - exp(-128 / R))) = 524352.
	 * The direct formula round(100 / (1 - exp(-128 / R))) = 409650.
	 */
	expect_u64_eq(prof_sample_weighted_size(100, 128, 524352), 409650,
	    "Weighted size should match the sampling formula");
}
TEST_END

int
main(void) {
	return test(test_prof_backtrace_hook_replace,
	    test_prof_backtrace_hook_augment, test_prof_dump_hook,
	    test_prof_sample_hooks, test_prof_hook_noop,
	    test_prof_sample_weighted_size);
}
