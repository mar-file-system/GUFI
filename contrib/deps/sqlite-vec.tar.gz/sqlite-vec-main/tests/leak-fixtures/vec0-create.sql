.load dist/vec0
.mode box
.header on
.eqp on
.echo on

create virtual table v using vec0(y);
