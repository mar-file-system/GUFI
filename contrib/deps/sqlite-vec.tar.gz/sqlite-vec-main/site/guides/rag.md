# Retrival Augmented Generation (RAG)

- "memories"?
- chunking
