# Vector Arithmetic

- `vec_add()`
- `vec_sub()`
- `vec_mean()`
