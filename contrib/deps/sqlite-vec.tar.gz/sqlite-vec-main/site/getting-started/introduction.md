# Introduction to `sqlite-vec`

## Intro to Vector Databases

## Vector Search in SQLite with `sqlite-vec`

## Getting help
