import sys
import socket
import json

if len(sys.argv)<3:
  print("python program modelname inputtext")
  sys.exit()
modelname=sys.argv[1]
inputtext=sys.argv[2]

SOCKET_PATH = "/tmp/%s.sock" % modelname

def get_embedding(text: str):
    client = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    client.connect(SOCKET_PATH)
    
    payload = json.dumps({"text": text}) 
    client.sendall(payload.encode("utf-8"))
    
    # Receive response
    response_data = b""
    while True:
        chunk = client.recv(4096)
        if not chunk:
            break
        response_data += chunk
        
    client.close()
    return json.loads(response_data.decode("utf-8"))["vector"]

if __name__ == "__main__":
    vector = get_embedding(inputtext)
    print(f"Received vector of length: {len(vector)}")
    print(f"First 5 dimensions: {vector[:5]}")
