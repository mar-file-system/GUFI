import os
import sys 
import socket
import json
from sentence_transformers import SentenceTransformer

if len(sys.argv)<4:
  print("python program modelname modelwordsize modelvectorlength")
  sys.exit()
modelname=sys.argv[1]
path = modelname.replace("/", "__")
modelwordsize=sys.argv[2]
modelvecttorlenfth=sys.argv[3]

#SOCKET_PATH = "/tmp/%s.sock" % modelname
SOCKET_PATH = "/tmp/%s.sock" % path 

# Remove existing socket file if it lingers from a previous run
if os.path.exists(SOCKET_PATH):
    os.unlink(SOCKET_PATH)

print("Loading embedding model...")
#model = SentenceTransformer(modelname)
model = SentenceTransformer(path)
print("Model loaded.")

server = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
server.bind(SOCKET_PATH)
server.listen(1)
os.chmod(SOCKET_PATH, 0o666)  # Adjust permissions as needed

print(f"Listening on Unix domain socket: {SOCKET_PATH}")

try:
    while True:
        conn, _ = server.accept()
        with conn:
            data = conn.recv(4096)
            if not data:
                continue
            
            payload = json.loads(data.decode("utf-8"))
            text = payload.get("text", "")
            
            # Convert text into vector embedding
            vector = model.encode(text).tolist()
            
            response = json.dumps({"vector": vector})
            #print(response)
            conn.sendall(response.encode("utf-8"))
finally:
    server.close()
    if os.path.exists(SOCKET_PATH):
        os.unlink(SOCKET_PATH)
