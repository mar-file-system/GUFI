import sys
import socket
import json

with open("/tmp/output.txt", "w", encoding="utf-8") as f:
  print("python program called ", file=f)
if len(sys.argv)<2:
  print("python program inputtext")
  with open("/tmp/output.txt", "w", encoding="utf-8") as f:
    print("python program inputtext", file=f)
  sys.exit()
inputtext=sys.argv[1]
with open("/tmp/output.txt", "w", encoding="utf-8") as f:
  print(f"python program called {inputtext} ", file=f)

models = [
    ['Qwen/Qwen3-Embedding-0.6B','sentence_transformer',1024],
    ['multi-qa-mpnet-base-dot-v1','sentence_transformer',768]
]
def get_embedding(text: str):
    client = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    client.connect(SOCKET_PATH)
    
    payload = json.dumps({"text": text}) 
    client.sendall(payload.encode("utf-8"))
    
    # Receive response
    response_data = b""
    while True:
        chunk = client.recv(4096)
        if not chunk:
            break
        response_data += chunk
        
    client.close()
    #return response_data 
    return json.loads(response_data.decode("utf-8"))["vector"]

if __name__ == "__main__":
    models = [
      ['Qwen/Qwen3-Embedding-0.6B','sentence_transformer',1024],
      ['multi-qa-mpnet-base-dot-v1','sentence_transformer',768]
    ]
    #print(inputtext)
    for row in models:
      #print(row[0])
      path = row[0].replace("/", "__")
      SOCKET_PATH = "/tmp/%s.sock" % path
      vector = get_embedding(inputtext)
      #print(f"Received vector of length: {len(vector)}")
      #print(f"First 5 dimensions: {vector[:5]}"
      with open("/tmp/output.txt", "a", encoding="utf-8") as f:
        print(f"lookup '{row[0]}';'{row[1]}';{row[2]};'{vector}'", file=f)
      #print(f"{row[0]};{row[1]};{row[2]};{vector}")
      myout=f"'{row[0]}'`;'{row[1]}';{row[2]};'{vector}'"
      sys.stdout.write(myout)
      sys.stdout.flush()
