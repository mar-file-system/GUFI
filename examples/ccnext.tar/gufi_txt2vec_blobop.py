import sys
import os 
import json
import socket
import struct

if len(sys.argv)<4:
  print("python program model_name model_type model_length text_string", file=sys.stderr)
  sys.exit()
model_name=sys.argv[1]
path = model_name.replace("/", "__")
model_type=sys.argv[2]
model_length=sys.argv[3]
text_string=sys.argv[4]


#****** for right now i will just hard code this to one model but it needs to handle different models or something like that
#model_name="modelsv1"

outline="*********python program model_name %s  model_type %s model_length %s text_stringi %s" % (model_name,model_type,model_length,text_string)
print(outline, file=sys.stderr)

#SOCKET_PATH = "/tmp/%s.sock" % model_name
SOCKET_PATH = "/tmp/%s.sock" % path

def get_embedding(text: str):
    client = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    client.connect(SOCKET_PATH)

    payload = json.dumps({"text": text})
    client.sendall(payload.encode("utf-8"))

    # Receive response
    response_data = b""
    while True:
        chunk = client.recv(4096)
        if not chunk:
            break
        response_data += chunk

    client.close()
    #print(response_data)
    return json.loads(response_data.decode("utf-8"))["vector"]

vector = get_embedding(text_string)
#print(f"Received vector of length: {len(vector)}")
#print(f"First 5 dimensions: {vector[:5]}")
binary_data = struct.pack(f"{len(vector)}f", *vector)
sys.stdout.buffer.write(binary_data)
sys.stdout.buffer.flush()

#query_embeddings = stmodel.encode(text_string,convert_to_numpy=True)[:int(model_length)].astype(np.float32)

