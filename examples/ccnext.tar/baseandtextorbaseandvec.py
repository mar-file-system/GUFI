import sys
import os 
import sqlite3
import sqlite_vec

# this stuff is in here so you could embed the input in python itself
#import json
#import struct
# this was required to get sentence transfomer and model.encode etc.
#from sentence_transformers import SentenceTransformer

#this program runs a gufi query a new external database permissions permutation dbs for gufi extracted from vaults
#the text (bm25) and vector tables are in permission permutation external dbs
#and also in the db.db
#it builds top k for each combo of model/mechanism and top k for bm25
#it uses rrf to rerank using frequency to get final top k
#it has input parms of
# full text search input field (from ext_bm25_v (both in ext_*.db and db.db) (temporary shoujld be ext_bm25_v when the view is fixed)
# path like input field (from vrpentries)
# file metadata input field (from ext_assets_by_file_v (both in ext_*.db and db.db)
# vector input phrase (from ext_vectors_v (both in ext_*.db and db.db)
# ******* the path and file metadata fields limit the text and vector search to only matches on path and/or file metadata which itself is AND as well

#prereq,you have to have sourced /Users/ggrider/pyvenv3.14/bin/activate which has vec0 python modules installed into that virtual env 

if len(sys.argv)<5:
  print("python program text-search-string pathname_string file_metadata_string vector-search-string indexpath")
  sys.exit()
textin=sys.argv[1]
filenamein=sys.argv[2]
filemetain=sys.argv[3]
queryphrase=sys.argv[4]
gufiindex=sys.argv[5]

#this stuff was to embed input in the python itself
#def serialize_float32(vector):
#    return struct.pack(f"{len(vector)}f", *vector)
#magic encantation to load the model locally and test to see if it loaded
#model = 'modelsv1/'
#stmodel = SentenceTransformer(model)
#query_embeddings = stmodel.encode(query)
#query_embeddingsto = stmodel.encode(query).tolist()
#vector_json_literal = f"'{json.dumps(query_embeddingsto)}'"
#query_blob = serialize_float32(query_embeddingsto)
#print("Embedding shape of query:", query_embeddings.shape)
#json_embedding = json.dumps(query_embeddings.tolist())
#print(json_embedding)

#models i want to use
#Qwen/Qwen3-Embedding-0.6B
#multi-qa-mpnet-base-dot-v1
#different-model

# ***** this section sets up some text strings used in the query ******
#g_index="/Users/ggrider/vaultiq/common-multi-model-index/idx/src"
#g_index="/Users/ggrider/vaultiq/spread-workflow-index/idx/src"
#g_index="/tmp/ccn9"
g_index=f"{gufiindex}"

#note this is _vv and not just _v - the _v external view didnt have bm25(ext_bm25) as rank **********************needs to be fixed
#CREATE VIEW ext_bm25_v AS SELECT s.inode,s.mtime,s.extra_info,s.outer_file_uuid,s.asset_id,s.chunk_sequence,s.start_position,s.end_position,s.page_start,s.page_end,s.audio_start_sec,s.video_start_sec,s.video_end_sec,s.content,a.component_type,a.member_path_json,a.file_metadata,a.indexing_provenance,a.mimetype,a.asset_route,bm25(ext_bm25) as rank FROM ext_bm25 s JOIN ext_assets a ON s.asset_id=a.asset_id AND s.outer_file_uuid=a.outer_file_uuid;

# bm25 is the external fields (not overlapped with base)
g_bm25="extra_info UNINDEXED,chunk_sequence UNINDEXED,start_position UNINDEXED,end_position UNINDEXED,page_start UNINDEXED,page_end UNINDEXED,audio_start_sec UNINDEXED,video_start_sec UNINDEXED,video_end_sec UNINDEXED,content,component_type UNINDEXED,member_path_json UNINDEXED,file_metadata UNINDEXED,indexing_provenance UNINDEXED,mimetype UNINDEXED,asset_route UNINDEXED,bm25rank UNINDEXED"
# *** notice the last field is not bm25rank (this is because rank needs to be calculated)
g_bm25list="e.extra_info,e.chunk_sequence,e.start_position,e.end_position,e.page_start,e.page_end,e.audio_start_sec,e.video_start_sec,e.video_end_sec,e.content,e.component_type,e.member_path_json,e.file_metadata,e.indexing_provenance,e.mimetype,e.asset_route"

#CREATE VIEW ext_vectors_v AS SELECT s.inode,s.mtime,s.extra_info,s.outer_file_uuid,s.asset_id,s.embedding_id,s.chunk_id,s.vector_mechanism,s.vector_model_name,s.vector_native_dimensions,s.vector_stored_dimensions,s.page_number,s.audio_start_sec,s.video_start_sec,s.video_end_sec,s.chunk_content,s.chunk_prefix,s.chunk_overlap,s.embedding,a.component_type,a.member_path_json,a.file_metadata,a.indexing_provenance,a.mimetype,a.asset_route FROM ext_vectors s JOIN ext_assets a ON s.asset_id=a.asset_id AND s.outer_file_uuid=a.outer_file_uuid;

# vectors is the vectors fields (not overlapped with base)
g_vectors="distance REAL,extra_info TEXT, vector_mechanism TEXT,vector_model_name TEXT,vector_native_dimensions INT64,vector_stored_dimensions INT64,page_number INT64,audio_start_sec FLOAT,video_start_sec FLOAT,video_end_sec FLOAT,chunk_content TEXT,chunk_prefix TEXT,chunk_overlap TEXT,component_type TEXT,member_path_json TEXT,file_metadata TEXT,indexing_provenance TEXT,mimetype TEXT,asset_route TEXT"
# *** notice it starts with extra_info and not with distance as distance needs to be caluclated
g_vectorslist="e.extra_info,e.vector_mechanism,e.vector_model_name,e.vector_native_dimensions,e.vector_stored_dimensions,e.page_number,e.audio_start_sec,e.video_start_sec,e.video_end_sec,e.chunk_content,e.chunk_prefix,e.chunk_overlap,e.component_type,e.member_path_json,e.file_metadata,e.indexing_provenance,e.mimetype,e.asset_route"

# this is the base gufi vrpentries fields, if you add a field to the base you need to add it to all 5 of these rows *****
g_base="inode INT64,mtime INT64,path TEXT,name TEXT,ctime INT64,atime INT64,size INT64,uid INT64,gid INT64,file_metadata_jsons TEXT"
g_baseun="inode UNINDEXED,mtime UNINDEXED,path UNINDEXED,name UNINDEXED,ctime UNINDEXED,atime UNINDEXED,size UNINDEXED,uid UNINDEXED,gid UNINDEXED,file_metadata_jsons UNINDEXED"
g_baseshort="inode,mtime,path,name,ctime,atime,size,uid,gid,file_metadata_jsons"
g_baselistb="b.inode,b.mtime,b.path,b.name,b.ctime,b.atime,b.size,b.uid,b.gid,b.file_metadata_jsons"
g_baseliste="e.inode,e.mtime,e.path,e.name,e.ctime,e.atime,e.size,e.uid,e.gid,e.file_metadata_jsons"

# this is the join to base from bm25 and vector queies  - if you want to add a join field you need to makd sure its in the
#   all the g_bm25* definitions
#   all the g_vectors* definitions
#   all the b_base* definitions
# for example if you wanted to join to extra_info in the bm23 and vector external views you might need to bring in another base field to join it with etc.
g_basejoin="cast(e.inode as INT64)=b.inode and cast(e.mtime as INT64)=b.mtime"

# defitions of other temp tables stat for gathering stats during the run and inp is where the modelnames used and embedded input text for each model
g_stat="path TEXT, status INT64, timestamp INT64"
g_inp="modelname text,modeltype text, modeldimension INT64,inputembedding blob"

# these are limits for number of records for top K limiting and trimming
g_topextract="5"
g_topaggregate="10"

# *************** this needs to be fixed so that sites can have their own models list for embeddings they have done
# attempting to allow sites to set the models they use - this is not working yet
os.environ["GUFI_MODELS"] = '(\'Qwen/Qwen3-Embedding-0.6B\',\'sentence_transformer\',1024),(\'multi-qa-mpnet-base-dot-v1\',\'sentence_transformer\',768)' 
testenv="select strop('echo $GUFI_MODELS');"

# ***** this section builds the query ******
myexec=f"""create virtual table temp.test using gufi_vt(threads=8,index=\"{g_index}\",verbose=1,
I=\"
  -- create interim tables  bm25 must be a virtual table so bm25 ranking can be done, vectors can be a normal table due to distancing is done on external-copy in from external dbs;
  -- stat table is to collect statisics for the run and base is a table used to hold inodes mtimes for the files in the directory that match the base query (like %name%);
  CREATE VIRTUAL TABLE int_bm25 USING fts5({g_baseun},{g_bm25});
  CREATE TABLE int_vectors ({g_base},{g_vectors});
  create table int_stat ({g_stat});
  create table int_base ({g_base});
\",
global_db_create=\"
  -- globally visible to all threads to hold modelnames and embedded input phrases that match modelnames;
  create table inputembed ({g_inp});
\",
global_db_insert=\"
  -- globally visible to all threads to hold modelnames and embedded input phrases that match modelnames - load that table via sending input phrase to model over unix domain sockets;
  insert into inputembed values ('Qwen/Qwen3-Embedding-0.6B','sentence_transformer',1024,blobop('python3 ./gufi_txt2vec_blobop.py Qwen/Qwen3-Embedding-0.6B sentence_transformer 1024 ''{queryphrase}'''));
  insert into inputembed values ('multi-qa-mpnet-base-dot-v1','sentence_transformer',768,blobop('python3 ./gufi_txt2vec_blobop.py multi-qa-mpnet-base-dot-v1 sentence_transformer 768 ''{queryphrase}'''));
\",
K=\"
  -- create aggregate tables bm25 must be a virtual table so bm25 ranking can be done, vectors can be a normal table due to distancing is done on external-copy in from external dbs;
  -- stat table is to collect statisics for the run;
  CREATE VIRTUAL TABLE agg_bm25 USING fts5({g_baseun},{g_bm25});
  CREATE TABLE agg_vectors ({g_base},{g_vectors});
  create table agg_stat ({g_stat});
\",
J=\"
  -- copy interims to aggregates;
  insert into agg_bm25 select * from int_bm25;
  insert into agg_vectors select * from int_vectors;
  insert into agg_stat select * from int_stat;
\",
external_copy=\"ext\" \"
  -- delete the base for each directory and do th base query to populate base which is used to join against for bm25 and vec queries;
  -- populate base from vrpentries and assets info
  delete from int_base;
  insert into int_base select b.inode,b.mtime,rpath(b.sname, b.sroll, b.name) as path,b.name,b.ctime,b.atime,b.size,b.uid,b.gid,e.file_metadata_jsons as base_file_metadata from vrpentries b join extdb.ext_assets_by_file_v e on {g_basejoin}  where path||b.name like '%%{filenamein}%%' and e.file_metadata_jsons like '%%{filemetain}%%';
  -- copy the ext_ .db records in for bm25 running the match query on the input txt - joined with base so we only get files from base query and order by rank and limit to top;
  insert into int_bm25 select {g_baselistb},{g_bm25list},e.rank from extdb.ext_bm25_v e join int_base b on {g_basejoin} where e.content MATCH '{textin}' order by e.rank limit {g_topextract};
  -- copy vec records in from ext_ .db run the distance calc join to base query and keep top few but for each combination of model and mechanism using the row_number() sqlite tool;
  with 
    vec_embed as (select {g_baselistb},vec_distance_cosine(substr(e.embedding,1,4*(e.vector_native_dimensions)),i.inputembedding ) as distance,{g_vectorslist} from extdb.ext_vectors_v e join int_base b on {g_basejoin} join inputembed i on e.vector_model_name=i.modelname),
    rankeditems as (select {g_baseliste},e.distance,{g_vectorslist},row_number() over (partition by e.vector_mechanism ,e.vector_model_name order by e.distance) as rn from vec_embed e) 
    insert into int_vectors 
    select {g_baseliste},e.distance,{g_vectorslist} from rankeditems e where e.rn<={g_topextract};
\",
internal_test=\"
  -- test for assets info notice you must use tree.  for the schema query as gufi attaches db.db as tree;
  select 1 from tree.sqlite_schema where type='view' and name='ext_assets_by_file_v';
\",
internal_copy=\"
  -- delete any info in base and pull in base info from vrpentries plus assets;
  delete from int_base;
  insert into int_base select b.inode,b.mtime,rpath(b.sname, b.sroll, b.name) as path,b.name,b.ctime,b.atime,b.size,b.uid,b.gid,e.file_metadata_jsons as base_file_metadata from tree.vrpentries b join tree.ext_assets_by_file_v e on {g_basejoin}  where path||b.name like '%%{filenamein}%%' and e.file_metadata_jsons like '%%{filemetain}%%';
\",
internal_test=\"
  -- test for bm25 info notice you must use tree.  for the schema query as gufi attaches db.db as tree;
  select 1 from tree.sqlite_schema where type='view' and name='ext_bm25_v';
\",
internal_copy=\"
  -- run text query;
  insert into int_bm25 select {g_baselistb},{g_bm25list},e.rank from tree.ext_bm25_v e join int_base b on {g_basejoin} where e.content match '{textin}' order by e.rank limit {g_topextract};
\",
internal_test=\"
  -- test for vector info notice you must use tree.  for the schema query as gufi attaches db.db as tree;
  select 1 from tree.sqlite_schema where type='view' and name='ext_vectors_v';
\",
internal_copy=\"
  -- copy vec records in from ext_ .db run the distance calc join to base query and keep top few but for each combination of model and mechanism using the row_number() sqlite tool;
  with 
    vec_embed as (select {g_baselistb},vec_distance_cosine(substr(e.embedding,1,4*(e.vector_native_dimensions)),i.inputembedding ) as distance,{g_vectorslist} from tree.ext_vectors_v e join int_base b on {g_basejoin} join inputembed i on e.vector_model_name=i.modelname),
    rankeditems as (select {g_baseliste},e.distance,{g_vectorslist},row_number() over (partition by e.vector_mechanism ,e.vector_model_name order by e.distance) as rn from vec_embed e) 
    insert into int_vectors 
    select {g_baseliste},e.distance,{g_vectorslist} from rankeditems e where e.rn<={g_topextract};
\",
E=\"
  -- you could trim the stats to keep track of longest time to process a directory or number of vectors processed..
  -- trim the interim per thread to a top few records - you have to use bm25 ranking mechanism on the table you are quering;
  delete from int_bm25 where rowid not in (select rowid from int_bm25 where content match '{textin}' order by bm25(int_bm25) limit {g_topextract});
  -- trim the interim per thread to a top few records per model/mechanism using the row_number() over tool;
  with 
    rankeditems as (select rowid as rid,row_number() over (partition by vector_mechanism ,vector_model_name order by distance) as rn from int_vectors), trimmeditems as (select rid from rankeditems where rn<={g_topextract}) delete from int_vectors where rowid not in (select rid from trimmeditems);
  insert into int_stat select rpath(sname,sroll),(select count(*) from int_vectors),unixepoch('now') from vrsummary;
\",
G=\"
  -- this creates an output table and the first row is a header row and sets the width of the output table;
  select 'HEADER:','v1','v2','v3','v4','v5','v6','v7','v8','v9','v10';
  -- put the stats collected into the output table;
  select 'STATS:',* from agg_stat;
  -- put the input embedded info into the output table;
  select 'INPUTEMBED:',modelname ,modeltype,  modeldimension, length(inputembedding) from inputembed ;
  -- put the bm25 top few records by rank into output table; 
  --  the agg_bm25 aggregated table has the entire set of external bm25 table columns and a lot of base vrpentries fields but could have more  or less if needed;
  with 
    ranked_bm25 as (select 'BM25:' as bm,path||'/'||name as pathname,bm25(agg_bm25) as grank,chunk_sequence,page_start,snippet(agg_bm25,12,'-->','<--','...',60)content from agg_bm25 where content match '{textin}' order by grank limit {g_topextract}) select bm,pathname,grank,page_start,substr(content,1,60),'bm25','bm25',row_number() over (partition by bm order by grank) from ranked_bm25;
  -- put the top few vec records per model/mechanism using row_number() over tool using distance into output table; 
  --  the agg_vectors aggregated table has the entire set of external vec0 table columns and a lot of base vrpentries fields but could have more or less if needed;
  with 
    rankeditems as (select path||'/'||name as pathname,distance,page_number,chunk_content,vector_mechanism,vector_model_name,row_number() over (partition by vector_mechanism ,vector_model_name order by distance) as rn from agg_vectors) select 'VECTORS:',pathname,distance,page_number,substr(chunk_content,1,10),vector_mechanism,vector_model_name,rn from rankeditems where rn<={g_topextract} order by vector_mechanism ,vector_model_name;
  -- put the vec top reranked by frequency records from bm25 top few results union all vec top few per model/mechansim then output fused ranked records  into output table; 
  --  notice a small subset of the agg_bm25 and agg_vectors fields, since those temp tables have most of base and text/base and vector info, you can pull out what yout want;
  --  first you build a subset of records of bm25 and vectors (ranked for each with vector ranking per model/mechanism) and then union those two 
  --  then you add rrf scores to all the unioned records that is per pathname  so a scored record per file (not subsets of a file)
  --  then you select the re-ranked using rrf and limit to get the final top files
  --  you could get top contents of files by changing this slightly
  with 
    rankedfin_bm25 as (select 'BM25:' as bm,path||'/'||name as pathname,bm25(agg_bm25) as grank,page_start,snippet(agg_bm25,12,'-->','<--','...',60)content from agg_bm25 where content match '{textin}' order by grank limit {g_topextract}), 
    finfin_bm25(ranktype,pathname,rank,page,content,mechanism,model,rn) as (select bm,pathname,grank,page_start,content,'bm25','bm25',row_number() over (partition by bm order by grank) from rankedfin_bm25),
    rankeditems as (select path||'/'||name as pathname,distance,page_number,chunk_content,vector_mechanism,vector_model_name,row_number() over (partition by vector_mechanism ,vector_model_name order by distance) as rn from agg_vectors), 
    finfin_vectors (ranktype,pathname,rank,page,content,mechanism,model,rn) as (select 'VECTORS:',pathname,distance,page_number,chunk_content,vector_mechanism,vector_model_name,rn from rankeditems where rn<=5 order by vector_mechanism ,vector_model_name), 
    finfin as (select * from finfin_bm25 union all select * from finfin_vectors), 
    fin_score as (select pathname,sum(1.0/(60.0 + rank)) as rrf_score from finfin group by pathname) 
    select 'perfile_rrfscore',ranktype,finfin.pathname,rank,page,substr(content,1,60),mechanism,model,rn,rrf_score from finfin join fin_score on finfin.pathname=fin_score.pathname order by rrf_score desc limit {g_topaggregate};
\")"""

#  insert into int_base select inode,mtime,rpath(sname, sroll, name) as path,name,ctime,atime,size,uid,gid from vrpentries where name like '%%{filenamein}%%';
# ************************  need to do  ******************
# need to fix inputembed mechanism to not list models!!!
#******* added pragma to turn safe schema on required to make use of bm25() in a view works - this is fixed in future versions of gufi

#print(myexec)
#sys.exit()

# ***** this section runs the query ***** 
try:
    with sqlite3.connect(':memory:') as conn:
        conn.enable_load_extension(True)
        cursor = conn.cursor()
        #conn.load_extension('/Users/ggrider/gufi-kt-04-14-26//GUFI-main/build/src/gufi_vt')
        #conn.load_extension('/Users/ggrider/gktattempt/GUFI-main/build/src/gufi_vt')
        #conn.load_extension('/Users/ggrider/gufi-100826/GUFI/build/src/gufi_vt')
        conn.load_extension('/Users/ggrider/gufi-110926/GUFI/build/src/gufi_vt')
        #conn.load_extension('/Users/ggrider/usr/local/lib/gufi_vt')
        #sqlite_vec.load(conn)
        conn.enable_load_extension(False)


        # set trusted_schema on - needed for using bm25() in a view
        setsafeon='PRAGMA trusted_schema = ON;'
        cursor.execute(setsafeon)

        cursor.execute(testenv)
        rows = cursor.fetchall()
        print("\noutput:\n")
        for row in rows:
            print(row[0])

        cursor.execute(myexec)
        #cursor.execute(myexec,data)
        #cursor.execute(myexec,{"vector_data": json_embedding})
        #cursor.execute(myexec,{"vector_data": query_blob})

        # there shouldnt be any rows fecthed here
        rows = cursor.fetchall()
        print("\noutput:\n")
        for row in rows:
            print(row)

        myfin="select * from temp.test"
        cursor.execute(myfin)
        rows = cursor.fetchall()
        print("\noutput:\n")
        for row in rows:
            print(row)
except sqlite3.Error as e:
    print(f"An SQLite error occurred: {e}")

